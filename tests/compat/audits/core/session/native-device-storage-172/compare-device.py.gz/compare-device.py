"""Bounded device response comparison; retains both raw responses in each pair."""
import json, pathlib, re
root = pathlib.Path('/tmp/better-auth-172-device')
source = json.loads((root/'evidence/source-workflow.json').read_text())
pairs = []
for backend in ['Sqlx', 'SeaOrm', 'without-database']:
    native = json.loads(pathlib.Path(f'/tmp/device172-evidence/{backend}-workflow.json').read_text())
    assert len(source) == len(native) == 28
    code_maps = [{}, {}]
    for i, (left, right) in enumerate(zip(source, native)):
        assert (left['path'], left['status']) == (right['path'], right['status'])
        values = [json.loads(left['body']), json.loads(right['body'])]
        if i < 2:
            # Identity signup is setup; assert its stable public fields separately.
            assert all(v['user']['name'] == ['owner', 'other'][i] for v in values)
            continue
        if left['path'] == '/device/code':
            for v, mapping in zip(values, code_maps):
                assert re.fullmatch('[A-Za-z0-9]{40}', v['device_code'])
                assert re.fullmatch('[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{8}', v['user_code'])
                mapping[v['device_code']] = f'<device-{i}>'
                mapping[v['user_code']] = f'<user-{i}>'
        if left['path'] == '/device/token' and left['status'] == 200:
            assert all(isinstance(v['access_token'], str) and v['access_token'] for v in values)
            assert abs(values[0]['expires_in'] - values[1]['expires_in']) <= 1
            for v in values:
                v['access_token'] = '<issued-token>'
                v['expires_in'] = '<session-lifetime-within-1-second>'
        normalized = []
        for v, mapping in zip(values, code_maps):
            raw = json.dumps(v, sort_keys=True)
            for actual, placeholder in mapping.items():
                raw = raw.replace(actual, placeholder)
            normalized.append(json.loads(raw))
        assert normalized[0] == normalized[1], (backend, i, normalized)
        pairs.append({'backend':backend, 'index':i, 'source':left, 'native':right, 'normalized':normalized[0]})
(root/'evidence/raw-pairs.json').write_text(json.dumps(pairs,indent=2))
source_restart=json.loads((root/'evidence/source-restart-workflow.json').read_text())
native_restart=json.loads(pathlib.Path('/tmp/device172-evidence/native-restart-workflow.json').read_text())
assert len(source_restart)==len(native_restart)==3
assert [(x['path'],x['status']) for x in source_restart]==[(x['path'],x['status']) for x in native_restart]
for a,b in zip(source_restart[1:],native_restart[1:]):
    assert json.loads(a['body'])==json.loads(b['body'])
print('78 device response pairs and restart rejection responses matched; raw responses retained')

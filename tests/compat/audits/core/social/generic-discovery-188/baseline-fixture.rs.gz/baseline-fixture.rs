//! Real discovery and provider HTTP authority for the generic SDK owner.
use crate::TestSchema;
use axum::{Json, Router, extract::{State, Path}, http::{HeaderMap, StatusCode}, routing::{get, post}};
use better_auth::{AuthBuilder, AuthConfig, AuthResult};
use better_auth::integrations::axum::AxumIntegration;
use better_auth::middleware::RateLimitConfig;
use better_auth::plugins::{EmailPasswordPlugin, OAuthPlugin, SessionManagementPlugin};
use better_auth::plugins::oauth::{OAuthProvider, OAuthAuthorizationPolicy, OAuthProfileMapper, OAuthUserInfoHandler, OAuthUserInfoRequest, OAuthUserInfoResponse, OAuthUserInfo};
use better_auth_seaorm::DatabaseConnection;
use serde_json::{Value, json};
use std::sync::Arc;
use tokio::sync::Mutex;
#[derive(Clone, Default)]
pub(crate) struct Fixture {control:Arc<Mutex<Value>>,receipts:Arc<Mutex<Vec<Value>>>,base:String}
impl Fixture {pub(crate) async fn reset(&self){*self.control.lock().await=json!({});self.receipts.lock().await.retain(|row|row["path"]=="/metadata");}}
struct Mapper;
#[async_trait::async_trait]
impl OAuthProfileMapper for Mapper {
 async fn map_profile(&self,_:Value)->Result<better_auth_core::field_policy::FieldOutput,String>{
  Ok([("id".into(),json!("mapped-id")),("name".into(),json!("Mapped Name"))].into_iter().collect())
 }
}
struct Custom(Fixture);
#[async_trait::async_trait]
impl OAuthUserInfoHandler for Custom {
 async fn get_user_info(&self,_:OAuthUserInfoRequest)->Result<OAuthUserInfoResponse,String>{
  self.0.receipts.lock().await.push(json!({"path":"/custom"}));
  let raw=self.0.control.lock().await["profile"].clone();
  Ok(OAuthUserInfoResponse{user_output:None,user:OAuthUserInfo{additional_fields:Default::default(),id:raw["id"].as_str().unwrap_or_default().into(),email:raw["email"].as_str().unwrap_or_default().into(),name:raw["name"].as_str().map(str::to_owned),image:None,email_verified:raw["emailVerified"].as_bool().unwrap_or(false)},data:raw})
 }
}
pub(crate) async fn router(config:&AuthConfig,database:DatabaseConnection)->AuthResult<(Router,Fixture)>{
 let listener=tokio::net::TcpListener::bind("127.0.0.1:0").await.map_err(|_|better_auth::AuthError::internal("Fixture listener failed"))?;
 let fixture=Fixture{base:format!("http://{}",listener.local_addr().map_err(|_|better_auth::AuthError::internal("Fixture address failed"))?),..Default::default()};
 let transport=Router::new().route("/metadata/keys",get(||async{Json(serde_json::from_str::<Value>(include_str!("../../../../fixtures/one-tap/jwks.json")).unwrap())}))
  .route("/metadata/{mode}",get(metadata)).route("/token/{kind}",post(token)).route("/user/{kind}",get(user)).with_state(fixture.clone());
 tokio::spawn(async move {let _result=axum::serve(listener,transport).await;});
 let mut router=Router::new();
 for mode in ["success","override","failed","fallback","invalid-issuer","invalid-jwks","required","oidc","mapped"]{
  let path=format!("/__test/profiles/generic-discovery-{mode}/api/auth"); let settings=config.clone().base_path(&path);
  let provider=OAuthProvider {
   client_id:"discovery-client".into(),client_secret:"discovery-secret".into(),additional_client_ids:Vec::new(),hosted_domain:None,require_email_verification:false,
   auth_url:String::new(),token_url:String::new(),user_info_url:None,scopes:vec!["profile".into()],authorization:Some(OAuthAuthorizationPolicy::default()),authorization_params:Vec::new(),account_subject:None,
   map_user_info:Some(|raw|Ok(OAuthUserInfo{additional_fields:Default::default(),id:raw["id"].as_str().unwrap_or_default().into(),email:raw["email"].as_str().unwrap_or_default().into(),name:raw["name"].as_str().map(str::to_owned),image:None,email_verified:raw["email_verified"].as_bool().unwrap_or(false)})),get_user_info:None,refresh_access_token:None,verify_id_token:None,id_token:None,disable_id_token_sign_in:false,disable_implicit_sign_up:false,disable_sign_up:false,override_user_info_on_sign_in:false,
  };
  let plugin=OAuthPlugin::new().add_provider("discovery",provider);
  let auth=Arc::new(AuthBuilder::<TestSchema>::new(settings.clone()).store(crate::backend::store::<TestSchema>(settings,database.clone()))
   .rate_limit(RateLimitConfig::new().enabled(false)).plugin(EmailPasswordPlugin::new().enable_username(false)).plugin(SessionManagementPlugin::new()).plugin(plugin).build().await?);
  router=router.nest(&path,auth.clone().axum_router().with_state(auth));
 }
 let controls=Router::new().route("/__test/generic-discovery/control",post(|State(f):State<Fixture>,Json(v):Json<Value>|async move{*f.control.lock().await=v;Json(json!({"status":true}))}))
  .route("/__test/generic-discovery/receipts",get(|State(f):State<Fixture>|async move{Json(f.receipts.lock().await.clone())})).with_state(fixture.clone());
 Ok((router.merge(controls),fixture))
}
async fn metadata(State(f):State<Fixture>,Path(mode):Path<String>,headers:HeaderMap)->(StatusCode,Json<Value>){
 f.receipts.lock().await.push(json!({"path":"/metadata","mode":mode,"header":headers.get("x-discovery").and_then(|v|v.to_str().ok())}));
 if ["failed","fallback","required"].contains(&mode.as_str()){return(StatusCode::SERVICE_UNAVAILABLE,Json(json!({"error":"metadata failed"})));}
 let mut document=json!({"authorization_endpoint":"https://discovered.example.invalid/authorize","token_endpoint":format!("{}/token/discovered",f.base),"userinfo_endpoint":format!("{}/user/discovered",f.base),"end_session_endpoint":"https://discovered.example.invalid/logout"});
 if mode=="invalid-issuer"{document["issuer"]=json!("not a url");}
 if mode=="invalid-jwks"{document["issuer"]=json!("https://issuer.example.invalid");document["jwks_uri"]=json!("http://[bad");}
 if mode=="oidc"{document["issuer"]=json!("https://issuer.example.invalid");document["jwks_uri"]=json!("keys");document["id_token_signing_alg_values_supported"]=json!(["RS256"]);}
 (StatusCode::OK,Json(document))
}
async fn token(State(f):State<Fixture>,Path(kind):Path<String>,headers:HeaderMap,raw:String)->(StatusCode,Json<Value>){
 let body:Vec<_>=url::form_urlencoded::parse(raw.as_bytes()).into_owned().collect();
 f.receipts.lock().await.push(json!({"path":format!("/token/{kind}"),"authorization":headers.get("authorization").and_then(|v|v.to_str().ok()),"body":body,"raw":raw}));
 let control=f.control.lock().await;
 (status(&control,"tokenStatus"),Json(control.get("tokenResponse").cloned().unwrap_or_else(||json!({"access_token":"discovery-access","refresh_token":"discovery-refresh","token_type":"Bearer","expires_in":3600,"scope":"profile"}))))
}
async fn user(State(f):State<Fixture>,Path(kind):Path<String>,headers:HeaderMap)->(StatusCode,Json<Value>){
 f.receipts.lock().await.push(json!({"path":format!("/user/{kind}"),"authorization":headers.get("authorization").and_then(|v|v.to_str().ok())}));
 let control=f.control.lock().await;
 (status(&control,"userStatus"),Json(control.get("profile").cloned().unwrap_or_else(||json!({"id":"discovery-subject","sub":"oidc-subject","email":"discovery@example.invalid","email_verified":true,"name":"Discovery Name"}))))
}
fn status(value:&Value,key:&str)->StatusCode{value.get(key).and_then(Value::as_u64).and_then(|v|u16::try_from(v).ok()).and_then(|v|StatusCode::from_u16(v).ok()).unwrap_or(StatusCode::OK)}

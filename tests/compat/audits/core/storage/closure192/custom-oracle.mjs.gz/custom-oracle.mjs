import {Kysely,PostgresDialect,sql} from 'kysely';
import pg from 'pg';import {kyselyAdapter} from '@better-auth/kysely-adapter';
const pool=new pg.Pool({connectionString:'postgres://close192@127.0.0.1:55492/postgres'});
const db=new Kysely({dialect:new PostgresDialect({pool}),log:e=>{if(e.query)console.log(JSON.stringify({sql:e.query.sql,parameters:e.query.parameters.map(v=>({type:typeof v,text:String(v)}))}));}}).withSchema('custom192');
await sql`alter table custom192.app_people add column if not exists large bigint not null default 2`.execute(db);
const a=kyselyAdapter(db,{type:'postgres',transaction:true})({user:{modelName:'app_people',fields:{email:'mailbox',emailVerified:'email_verified',createdAt:'created_at',updatedAt:'updated_at'},additionalFields:{score:{type:'number',required:false},large:{type:'number',required:false}}},advanced:{database:{defaultFindManyLimit:1}}});
for(const value of ['1.5','0x1','1e0','Infinity','NaN','','9007199254740993']){
try {console.log(JSON.stringify({value,rows:await a.findMany({model:'user',where:[{field:'score',operator:'gt',value}],sortBy:{field:'score',direction:'asc'}})}));}catch(e){console.log(JSON.stringify({value,error:e.message,code:e.code}));}
}
for (const values of [['0x1','2e0'],['0x1','invalid'],[]]) {try { console.log(JSON.stringify({values,rows:await a.findMany({model:'user',where:[{field:'score',operator:'in',value:values}]} )}));}catch(e){console.log(JSON.stringify({values,error:e.message,code:e.code}));}}
try {await a.findMany({model:'user',where:[{field:'large',operator:'in',value:['1e0','NaN']}]});}catch(e){console.log(JSON.stringify({integerInvalidArray:['1e0','NaN'],error:e.message,code:e.code}));}
await db.destroy();

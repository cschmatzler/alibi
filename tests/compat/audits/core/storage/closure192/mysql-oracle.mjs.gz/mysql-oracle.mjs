import {Kysely, MysqlDialect, sql} from 'kysely';
import mysql from 'mysql2';
import {kyselyAdapter} from '@better-auth/kysely-adapter';
const pool=mysql.createPool({host:'127.0.0.1',port:55493,user:'root',database:'close192'});
const db=new Kysely({dialect:new MysqlDialect({pool})});
await sql`create table if not exists user (id varchar(40) primary key, name text, email varchar(255), emailVerified boolean, createdAt datetime(3), updatedAt datetime(3))`.execute(db);
await sql`delete from user`.execute(db);
for(let n=1;n<=4;n++)await sql`insert into user values (${String(n)},${String(n)},${n+'@example.com'},true,now(),now())`.execute(db);
const adapter=kyselyAdapter(db,{type:'mysql'})({});
for(const n of [undefined,0,1,2,1.5,-1,NaN,Infinity,-Infinity])for(const key of ['limit','offset']){
 try{const rows=await adapter.findMany({model:'user',sortBy:{field:'id',direction:'asc'},[key]:n});console.log(JSON.stringify({key,n:String(n),ids:rows.map(r=>r.id)}));}catch(e){console.log(JSON.stringify({key,n:String(n),error:e.message,code:e.code}));}
}
console.log(JSON.stringify({version:(await sql`select version() as v`.execute(db)).rows}));
await db.destroy();

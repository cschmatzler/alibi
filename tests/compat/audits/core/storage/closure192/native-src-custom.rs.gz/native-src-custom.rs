use better_auth_core::{AuthSchema,AuthConfig,AuthUser,CreateUser,ListUsersParams,UserFilterValue,store::UserStore};
use chrono::{DateTime,Utc};
use std::sync::Arc;
mod sx {
use super::*;
#[derive(Clone,Debug,serde::Serialize,sqlx::FromRow,better_auth_sqlx::AuthEntity)]
#[auth(role="user",table="app_people")]
pub struct Model {
 pub id:String,
 #[sqlx(rename="mailbox")] pub email:Option<String>,
 pub name:Option<String>,pub email_verified:bool,pub image:Option<String>,pub created_at:chrono::DateTime<Utc>,pub updated_at:chrono::DateTime<Utc>,pub score:Option<f64>,
}
pub struct Schema;impl AuthSchema for Schema {type User=Model;type Session=better_auth_sqlx::store::entities::session::Model;type Account=better_auth_sqlx::store::entities::account::Model;type Verification=better_auth_sqlx::store::entities::verification::Model;}
}
mod so {
use super::*;use sea_orm::entity::prelude::*;
#[derive(Clone,Debug,serde::Serialize,DeriveEntityModel,better_auth_seaorm::AuthEntity)]
#[auth(role="user")]
#[sea_orm(table_name="app_people")]
pub struct Model {
 #[sea_orm(primary_key,auto_increment=false)]pub id:String,
 #[sea_orm(column_name="mailbox")]pub email:Option<String>,
 pub name:Option<String>,pub email_verified:bool,pub image:Option<String>,pub created_at:chrono::DateTime<Utc>,pub updated_at:chrono::DateTime<Utc>,pub score:Option<f64>,
}
#[derive(Copy,Clone,Debug,EnumIter,DeriveRelation)]pub enum Relation{}
impl ActiveModelBehavior for ActiveModel{}
pub struct Schema;impl AuthSchema for Schema{type User=Model;type Session=better_auth_seaorm::store::entities::session::Model;type Account=better_auth_seaorm::store::entities::account::Model;type Verification=better_auth_seaorm::store::entities::verification::Model;}
}
pub async fn run()->Result<(),Box<dyn std::error::Error>>{
let url="postgres://close192@127.0.0.1:55492/postgres?options=-csearch_path%3Dcustom192";
let pool=better_auth_sqlx::SqlxPool::connect(url).await?;
let raw=pool.as_postgres().unwrap();
sqlx::query("CREATE TABLE app_people (id text primary key, mailbox text unique,name text,email_verified boolean not null,image text,created_at timestamptz not null,updated_at timestamptz not null,score double precision)").execute(raw).await?;
let sx=better_auth_sqlx::SqlxStore::<sx::Schema>::new(Arc::new(AuthConfig::new("close192-owned-renamed-schema-secret")),pool.clone());
let user=sx.create_user(CreateUser::new().with_email("custom@example.com")).await?;
sqlx::query("update app_people set score=2 where id=$1").bind(user.id().as_ref()).execute(raw).await?;
let db=better_auth_seaorm::Database::connect(url).await?;
let so=better_auth_seaorm::SeaOrmStore::<so::Schema>::new(Arc::new(AuthConfig::new("close192-owned-renamed-schema-secret")),db.clone());
let p=ListUsersParams{filter_field:Some("score".into()),filter_value:Some(UserFilterValue::Scalar("1.5".into())),filter_operator:Some("gt".into()),sort_by:Some("score".into()),..Default::default()};
println!("custom SQLx numeric filter: {:?}",sx.list_users(p.clone()).await);
println!("custom SeaORM numeric filter: {:?}",so.list_users(p).await);
println!("custom raw physical: {:?}",sqlx::query("select id,mailbox,score from app_people order by id").fetch_all(raw).await?);
pool.close().await;db.close().await?;Ok(())
}

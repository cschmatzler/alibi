mod custom;
use better_auth_core::{AuthConfig, AuthUser, CreateUser, AuthSchema, CreateOrganization, CreateTeam, store::{SchemaMigrator, UserStore, AuthStore}};
use std::sync::Arc;
#[tokio::main]
async fn main()->Result<(),Box<dyn std::error::Error>>{
 custom::run().await?;
 let url="postgres://close192@127.0.0.1:55492/postgres?options=-csearch_path%3Dnative192";
 let pool=better_auth_sqlx::SqlxPool::connect(url).await?;
 let store=better_auth_sqlx::SqlxStore::<better_auth_sqlx::store::__private_test_support::bundled_schema::BundledSchema>::new(Arc::new(AuthConfig::new("owned-close192-proof-secret-32-characters")),pool.clone());
 store.migrate().await?;
 let mut ids=Vec::new();for n in 0..4{ids.push(store.create_user(CreateUser::new().with_email(format!("page{n}@example.com"))).await?.id().to_string());}
 let db=better_auth_seaorm::Database::connect(url).await?;
 let sea=better_auth_seaorm::SeaOrmStore::<better_auth_seaorm::store::__private_test_support::bundled_schema::BundledSchema>::new(Arc::new(AuthConfig::new("owned-close192-proof-secret-32-characters")),db.clone());
 for n in [0.,1.,2.,1.5,-1.,f64::NAN,f64::INFINITY,f64::NEG_INFINITY]{
  println!("SQLx limit {n}: {:?}",store.list_users_by_ids_page(&ids,n).await.map(|r|r.len()));
  println!("SeaORM limit {n}: {:?}",sea.list_users_by_ids_page(&ids,n).await.map(|r|r.len()));
 }
 seats(&store, "sqlx", &ids[0]).await?; seats(&sea,"seaorm",&ids[0]).await?;
 pool.close().await;db.close().await?; Ok(())
}

async fn seats<S:AuthSchema>(store:&dyn AuthStore<S>, backend:&str, user:&str)->Result<(),Box<dyn std::error::Error>>{
 let org=store.create_organization(CreateOrganization::new(backend,backend)).await?;
 for (i,n) in [0.,1.,1.5,-1.,f64::NAN,f64::INFINITY,f64::NEG_INFINITY,9007199254740992.].into_iter().enumerate(){
 let room=store.create_team(CreateTeam{organization_id:org.id.clone(),name:format!("{i}"),updated_at:None}).await?;
 let result=store.add_team_member(&room.id,user,Some(n)).await;
 println!("{backend} quota {n}: {result:?}; physical memberships {:?}",store.list_team_members(&room.id).await?);
 }
 Ok(())
}

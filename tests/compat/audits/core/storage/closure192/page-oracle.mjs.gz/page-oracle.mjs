import {Kysely, PostgresDialect, sql} from 'kysely';
import pg from 'pg';
import {kyselyAdapter} from '@better-auth/kysely-adapter';
const pool=new pg.Pool({connectionString:'postgres://close192@127.0.0.1:55492/postgres'});
const db=new Kysely({dialect:new PostgresDialect({pool})});
await sql`create table if not exists "user" (id text primary key, name text, email text, "emailVerified" boolean, "createdAt" timestamptz, "updatedAt" timestamptz)`.execute(db);
await sql`truncate "user"`.execute(db);
await sql`insert into "user" select n::text, n::text, n::text||'@example.com',true,now(),now() from generate_series(1,4) n`.execute(db);
const adapter=kyselyAdapter(db,{type:'postgres'})({});
console.log(JSON.stringify({physicalBefore:(await pool.query('select * from \"user\" order by id')).rows}));
const client=await pool.connect();
for (const n of [0,-0,1.5,-1,NaN,Infinity,-Infinity,1e-7,1e20,1e21,9007199254740993]) {
 try {const r=await client.query({text:'SELECT $1::bigint AS parsed',values:[n]});console.log(JSON.stringify({parameter:n.toString(),result:r.rows}));}
 catch(e){console.log(JSON.stringify({parameter:n.toString(),error:e.message,code:e.code}));}
}
client.release();
for(const n of [undefined,0,-0,1,2,1.5,-1,NaN,Infinity,-Infinity,1e-7,1e20,1e21,9007199254740993]){
 for(const key of ['limit','offset']){
  try{const rows=await adapter.findMany({model:'user',sortBy:{field:'id',direction:'asc'},[key]:n}); console.log(JSON.stringify({key,n:String(n),ids:rows.map(r=>r.id)}));}catch(e){console.log(JSON.stringify({key,n:String(n),error:e.message,code:e.code}));}
 }
}
console.log(JSON.stringify({physicalAfter:(await pool.query('select * from \"user\" order by id')).rows}));
await db.destroy();

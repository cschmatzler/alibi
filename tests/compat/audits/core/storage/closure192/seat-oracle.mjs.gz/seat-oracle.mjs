import {Kysely, PostgresDialect, sql} from 'kysely';
import pg from 'pg';
import {kyselyAdapter} from '@better-auth/kysely-adapter';
import {organization} from 'better-auth/plugins';
const pool=new pg.Pool({connectionString:'postgres://close192@127.0.0.1:55492/postgres'});
const db=new Kysely({dialect:new PostgresDialect({pool})});
await sql`create table if not exists team (id text primary key, name text, "organizationId" text, "memberCount" integer not null, "createdAt" timestamptz, "updatedAt" timestamptz)`.execute(db);
const a=kyselyAdapter(db,{type:'postgres',transaction:true})({plugins:[organization({teams:{enabled:true}})]});
for(const n of [0,1,1.5,-1,NaN,Infinity,-Infinity,9007199254740993]){
 await sql`delete from team`.execute(db);await sql`insert into team values ('one','one','org',0,now(),now())`.execute(db);
 try{const r=await a.incrementOne({model:'team',where:[{field:'id',value:'one'},{field:'memberCount',operator:'lt',value:n}],increment:{memberCount:1}});console.log(JSON.stringify({n:String(n),r,physical:(await sql`select * from team`.execute(db)).rows}));}catch(e){console.log(JSON.stringify({n:String(n),error:e.message,code:e.code,physical:(await sql`select * from team`.execute(db)).rows}));}
}
await db.destroy();

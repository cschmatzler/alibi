#!/usr/bin/env bash
set -uo pipefail
cd /tmp/better-auth-final-verification-20261004/ott-composition-repair
export BUN_INSTALL_CACHE_DIR=/tmp/better-auth-final-verification-20261004/ott-composition-bun-cache
export CARGO_BUILD_JOBS=2 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_TARGET_DIR=/tmp/better-auth-final-verification-20261004/ott-composition-target
export BETTER_AUTH_REQUIRE_REFERENCE_SERVER=1 NO_PROXY=localhost,127.0.0.1 no_proxy=localhost,127.0.0.1
export BETTER_AUTH_COMPAT_PATHS='tests/plugins/one-time-token/composition.test.ts tests/plugins/one-time-token/one-time-token.test.ts tests/plugins/one-time-token/custom-callback.test.ts'
R=/tmp/better-auth-final-verification-20261004/reports/ott-composition
for backend in sqlx seaorm; do
 export BETTER_AUTH_COMPAT_BACKEND="$backend" COMPAT_OBSERVATIONS_DIR="$R/final-$backend-raw"
 cargo nextest run --locked --test compat --run-ignored only --no-capture -E 'test(=sdk::tests::selected_client_compat)' > "$R/final-$backend.log" 2>&1
 rc=$?
 printf '%s %s\n' "$backend" "$rc" >> "$R/final-status.txt"
done
unset BETTER_AUTH_COMPAT_BACKEND
for backend in sqlx seaorm; do
 if [ "$backend" = seaorm ]; then args=(--features seaorm); else args=(); fi
 cargo clippy --locked --manifest-path tests/compat/rust-server/Cargo.toml --all-targets "${args[@]}" -- -D warnings > "$R/clippy-$backend.log" 2>&1
 printf 'clippy-%s %s\n' "$backend" "$?" >> "$R/final-status.txt"
done

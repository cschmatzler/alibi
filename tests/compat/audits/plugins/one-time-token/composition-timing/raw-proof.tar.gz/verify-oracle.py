import urllib.request,tarfile,io,hashlib,json,pathlib,datetime
root=pathlib.Path('/tmp/better-auth-final-verification-20261004')
results=[]
for package in ['better-auth','@better-auth/api-key','@better-auth/passkey']:
    meta=json.load(urllib.request.urlopen('https://registry.npmjs.org/'+package.replace('/','%2f')+'/1.7.6'))
    data=urllib.request.urlopen(meta['dist']['tarball']).read()
    digest='sha512-'+__import__('base64').b64encode(hashlib.sha512(data).digest()).decode()
    assert digest==meta['dist']['integrity'],package
    archive=tarfile.open(fileobj=io.BytesIO(data),mode='r:gz')
    for project in ['reference-server','client-tests']:
        installed=root/'ott-composition-repair/tests/compat'/project/'node_modules'/package
        mismatch=[]; count=0
        for item in archive:
            if not item.isfile(): continue
            path=installed/pathlib.Path(item.name).relative_to('package')
            count+=1
            if not path.is_file() or path.read_bytes()!=archive.extractfile(item).read(): mismatch.append(str(path))
        results.append(dict(package=package,version=meta['version'],project=project,tarball=meta['dist']['tarball'],integrity=digest,files_checked=count,mismatches=mismatch))
        archive.close(); archive=tarfile.open(fileobj=io.BytesIO(data),mode='r:gz')
with open(root/'reports/ott-composition/oracle-provenance.json','w') as f: json.dump(dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),results=results),f,indent=2)
assert all(not x['mismatches'] for x in results)
print(json.dumps(results,indent=2))

Organization-role adapters currently reject legacy non-record JSON before the endpoint can enforce its own boundary. Store literal permission text and defer JSON parsing to authorized role consumers; validate permission records only during dynamic grant loading. Typed create/update inputs remain records and omitted-permission batch updates retain every row’s literal grants.

Published Better Auth 1.7.6 SQLite probes confirm read/list/delete of non-record JSON without AC, exact invalid-record loader errors with AC, empty 500s for malformed JSON, and update truthiness/page behavior. Both adapter entity conversions now retain literal text. Source hashes, raw probes and build logs are retained in `/tmp/issue220-representation-evidence`.

Draft production checkpoint. Focused actual SQLx and SeaORM boundary regressions and self-review are in progress; no full sweep or hosted validation is claimed. Refs #220; alternative operator consumers remain open.

import subprocess,os,socket,time,urllib.request,urllib.error,http.cookiejar,json,pathlib
root=pathlib.Path('/tmp/better-auth-220-representation'); ev=pathlib.Path('/tmp/issue220-representation-evidence')
s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close();base=f'http://localhost:{port}'
f=open(ev/'source-sql-null-server.log','w');p=subprocess.Popen(['bun','run','server-sql-null-probe.ts'],cwd=root/'tests/compat/reference-server',env=dict(os.environ,PORT=str(port),NODE_ENV='production'),stdout=f,stderr=subprocess.STDOUT)
rows=[]
try:
 for _ in range(150):
  try:urllib.request.urlopen(base+'/__health');break
  except OSError:time.sleep(.2)
 for profile in ['org-roles-no-ac']:
  jar=http.cookiejar.CookieJar();op=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
  def req(path,body=None,method=None):
   r=urllib.request.Request(base+path,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json','Origin':base},method=method)
   try:res=op.open(r)
   except urllib.error.HTTPError as e:res=e
   t=res.read().decode();return {'status':res.status,'text':t,'body':json.loads(t) if t and t[0] in '{[' else t}
  prefix=f'/__test/profiles/{profile}/api/auth'
  signup=req(prefix+'/sign-up/email',{'email':f'{profile}@example.test','password':'password123','name':'probe'});assert signup['status']==200,signup
  for n,raw in enumerate(['null']):
   signup=req(prefix+'/sign-up/email',{'email':f'{profile}-{n}@example.test','password':'password123','name':'probe'});assert signup['status']==200,signup
   created=req(prefix+'/organization/create',{'name':f'probe{n}','slug':f'{profile}-{n}'});assert created['status']==200,created;org=created['body']['id']
   seeded=req('/__test/organization-api',{'profile':profile,'operation':'seed-role','organizationId':org,'role':'legacy','permissionJson':raw});assert seeded['status']==200,seeded
   rid=seeded['body']['roleId'];out={'profile':profile,'raw':raw};out['sqlNull']=req('/__test/organization-api',{'profile':profile,'operation':'probe-sql-null','roleId':rid})
   out['read']=req(prefix+f'/organization/get-role?organizationId={org}&roleId={rid}')
   out['list']=req(prefix+f'/organization/list-roles?organizationId={org}')
   out['permission']=req(prefix+'/organization/has-permission',{'organizationId':org,'permissions':{'team':['create']}})
   out['update']=req(prefix+'/organization/update-role',{'organizationId':org,'roleId':rid,'data':{'roleName':'renamed'}})
   out['delete']=req(prefix+'/organization/delete-role',{'organizationId':org,'roleId':rid})
   out['state']=req(f'/__test/organization-state?profile={profile}&organizationId={org}')
   rows.append(out)
 (ev/'source-sql-null-probe.json').write_text(json.dumps(rows,indent=2))
 for r in rows: print(r['profile'],repr(r['raw']),{k:(r[k]['status'],r[k]['body'] if r[k]['status']!=200 else 'ok') for k in ['read','list','permission','update','delete']})
finally:p.terminate();p.wait();f.close()

import { betterAuth } from '/tmp/better-auth-172-organization/tests/compat/reference-server/node_modules/better-auth/dist/index.mjs';
import { organization } from '/tmp/better-auth-172-organization/tests/compat/reference-server/node_modules/better-auth/dist/plugins/organization/index.mjs';
import { createAccessControl } from '/tmp/better-auth-172-organization/tests/compat/reference-server/node_modules/better-auth/dist/plugins/access/index.mjs';
import { defaultStatements } from '/tmp/better-auth-172-organization/tests/compat/reference-server/node_modules/better-auth/dist/plugins/organization/access/index.mjs';
const origin='http://localhost:43178';
function build() {return betterAuth({secret:'native-organization-172-secret-at-least-32',baseURL:origin,emailAndPassword:{enabled:true},rateLimit:{enabled:false},plugins:[organization({teams:{enabled:true,defaultTeam:{enabled:false},allowRemovingAllTeams:true,maximumMembersPerTeam:1},ac:createAccessControl(defaultStatements),dynamicAccessControl:{enabled:true}})]});}
const auth=build(); const trace:any[]=[];
async function call(path:string,input:any,cookie='',query:any={}) {
 const url=new URL(origin+'/api/auth'+path);for(const [k,v] of Object.entries(query))url.searchParams.set(k,String(v));
 const res=await auth.handler(new Request(url,{method:input===null?'GET':'POST',headers:{origin,'content-type':'application/json',cookie},...(input===null?{}:{body:JSON.stringify(input)})}));
 const raw=await res.text();const out=raw?JSON.parse(raw):null;
 trace.push({path,status:res.status,body:raw,cookies:res.headers.getSetCookie()});
 return {out,cookie:res.headers.getSetCookie().map(v=>v.split(';')[0]).join('; ')};
}
async function signup(email:string){const r=await call('/sign-up/email',{email,password:'Password123!',name:email});return {...r,id:r.out.user.id};}
const owner=await signup('owner@native-org.test'),member=await signup('member@native-org.test'),outsider=await signup('outsider@native-org.test');
const org=(await call('/organization/create',{name:'Native',slug:'native',metadata:{literal:null}},owner.cookie)).out.id;
const foreign=(await call('/organization/create',{name:'Foreign',slug:'foreign'},outsider.cookie)).out.id;
const role=(await call('/organization/create-role',{organizationId:org,role:'reviewer',permission:{organization:['update']}},owner.cookie)).out.roleData.id;
const temporary=(await call('/organization/create-role',{organizationId:org,role:'temporary',permission:{}},owner.cookie)).out.roleData.id;
await call('/organization/delete-role',{organizationId:org,roleId:temporary},owner.cookie);
const team=(await call('/organization/create-team',{organizationId:org,name:'One seat'},owner.cookie)).out.id;
const invite=(await call('/organization/invite-member',{organizationId:org,email:'member@native-org.test',role:'reviewer',teamId:team},owner.cookie)).out.id;
const pending=(await call('/organization/invite-member',{organizationId:org,email:'outsider@native-org.test',role:'member',teamId:team},owner.cookie)).out.id;
await call('/organization/accept-invitation',{invitationId:invite},outsider.cookie);
await call('/organization/accept-invitation',{invitationId:invite},member.cookie);
await call('/organization/accept-invitation',{invitationId:invite},member.cookie);
await call('/organization/accept-invitation',{invitationId:pending},outsider.cookie);
await call('/organization/update',{organizationId:foreign,data:{name:'Forbidden'}},member.cookie);
await call('/organization/update',{organizationId:org,data:{name:'Reviewed'}},member.cookie);
await call('/organization/update-role',{organizationId:org,roleId:role,data:{permission:{organization:[]}}},owner.cookie);
await call('/organization/get-role',null,owner.cookie,{organizationId:org,roleId:role});
const ctx=await auth.$context;const membership=await ctx.adapter.findOne({model:'member',where:[{field:'organizationId',value:org},{field:'userId',value:member.id}]});
await call('/organization/update-member-role',{organizationId:org,memberId:membership.id,role:'member'},owner.cookie);
await call('/organization/update',{organizationId:org,data:{name:'Denied'}},member.cookie);
await call('/organization/list-members',null,owner.cookie,{organizationId:org,filterField:'role',filterValue:'owner',filterOperator:'ne'});
await call('/organization/remove-team',{organizationId:foreign,teamId:team},outsider.cookie);
await call('/organization/remove-team',{organizationId:org,teamId:team},owner.cookie);
await call('/organization/remove-member',{organizationId:org,memberIdOrEmail:membership.id},owner.cookie);
const tables:any={};for(const model of ['organization','member','invitation','team','teamMember','organizationRole'])tables[model]=await ctx.adapter.findMany({model,limit:1000});
await call('/organization/delete',{organizationId:org},owner.cookie);
const deleted:any={};for(const model of ['organization','member','invitation','team','teamMember','organizationRole'])deleted[model]=await ctx.adapter.findMany({model,limit:1000});
const fresh=await build().$context;
const restart=await fresh.adapter.findOne({model:'organization',where:[{field:'id',value:org}]});
console.log(JSON.stringify({version:'1.7.6',trace,tables,deleted,restart},null,2));
const probes:any={};
await ctx.adapter.create({model:'member',data:{organizationId:foreign,userId:owner.id,role:'alpha',createdAt:new Date()}});
await ctx.adapter.create({model:'member',data:{organizationId:foreign,userId:member.id,role:'beta',createdAt:new Date()}});
probes.emptyPatch=await ctx.adapter.update({model:'organization',where:[{field:'id',value:foreign}],update:{}});
probes.pages=[];
for(const [offset,limit] of [[0,1.9],[-2.9,1.9],[0,-1.9],[-0.5,2.5]]) {
 const rows=await ctx.adapter.findMany({model:'member',where:[{field:'organizationId',value:foreign}],offset,limit});
 probes.pages.push({offset,limit,roles:rows.map(r=>r.role)});
}
const baseTeam=await ctx.adapter.create({model:'team',data:{organizationId:foreign,name:'Base',createdAt:new Date(),memberCount:0}});
let staged:any,release:any;
const ready=new Promise(r=>staged=r), released=new Promise(r=>release=r);
const tx=ctx.adapter.transaction(async inner=>{
 await inner.incrementOne({model:'team',where:[{field:'id',value:baseTeam.id}],increment:{memberCount:1}});
 await inner.create({model:'teamMember',data:{teamId:baseTeam.id,userId:owner.id,createdAt:new Date()}});
 staged();await released;
});
await ready;
await ctx.adapter.delete({model:'team',where:[{field:'id',value:baseTeam.id}]});
await ctx.adapter.create({model:'team',data:{organizationId:foreign,name:'Concurrent',createdAt:new Date(),memberCount:0}});
release();await tx;
probes.merge={team:await ctx.adapter.findOne({model:'team',where:[{field:'id',value:baseTeam.id}]}),members:await ctx.adapter.findMany({model:'teamMember',where:[{field:'teamId',value:baseTeam.id}]}),concurrent:await ctx.adapter.findMany({model:'team',where:[{field:'name',value:'Concurrent'}]})};
await Bun.write('/tmp/better-auth-172-organization-runtime/evidence/source-store-probes.json',JSON.stringify(probes,null,2));
